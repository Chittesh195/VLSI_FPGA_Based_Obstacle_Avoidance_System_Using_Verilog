# Basys 3 Master Clock
set_property -dict { PACKAGE_PIN W5 IOSTANDARD LVCMOS33 } [get_ports clk]
create_clock -period 10.000 -name sys_clk_pin -waveform {0.000 5.000} [get_ports clk]

## Reset Button
set_property -dict { PACKAGE_PIN U18  IOSTANDARD LVCMOS33 } [get_ports reset];

## UART Transmit Signal (output to ESP32)
set_property -dict { PACKAGE_PIN A16  IOSTANDARD LVCMOS33 } [get_ports {uart_tx_pin}];

## Trigger signal (output to ultrasonic sensor)
set_property -dict { PACKAGE_PIN K17  IOSTANDARD LVCMOS33 } [get_ports trig];

## Echo signal (input from ultrasonic sensor)
set_property -dict { PACKAGE_PIN N17  IOSTANDARD LVCMOS33 } [get_ports echo];

## 7-Segment Display (segments)
set_property -dict { PACKAGE_PIN W7   IOSTANDARD LVCMOS33 } [get_ports {seg[0]}];
set_property -dict { PACKAGE_PIN W6   IOSTANDARD LVCMOS33 } [get_ports {seg[1]}];
set_property -dict { PACKAGE_PIN U8   IOSTANDARD LVCMOS33 } [get_ports {seg[2]}];
set_property -dict { PACKAGE_PIN V8   IOSTANDARD LVCMOS33 } [get_ports {seg[3]}];
set_property -dict { PACKAGE_PIN U5   IOSTANDARD LVCMOS33 } [get_ports {seg[4]}];
set_property -dict { PACKAGE_PIN V5   IOSTANDARD LVCMOS33 } [get_ports {seg[5]}];
set_property -dict { PACKAGE_PIN U7   IOSTANDARD LVCMOS33 } [get_ports {seg[6]}];

## 7-Segment Display (anodes)
set_property -dict { PACKAGE_PIN U2   IOSTANDARD LVCMOS33 } [get_ports {an[0]}];
set_property -dict { PACKAGE_PIN U4   IOSTANDARD LVCMOS33 } [get_ports {an[1]}];
set_property -dict { PACKAGE_PIN V4   IOSTANDARD LVCMOS33 } [get_ports {an[2]}];
set_property -dict { PACKAGE_PIN W4   IOSTANDARD LVCMOS33 } [get_ports {an[3]}];

## Basys 3 LEDs (for debugging BCD outputs)
set_property -dict { PACKAGE_PIN U16  IOSTANDARD LVCMOS33 } [get_ports {cm0[0]}];
set_property -dict { PACKAGE_PIN E19  IOSTANDARD LVCMOS33 } [get_ports {cm0[1]}];
set_property -dict { PACKAGE_PIN U19  IOSTANDARD LVCMOS33 } [get_ports {cm0[2]}];
set_property -dict { PACKAGE_PIN V19  IOSTANDARD LVCMOS33 } [get_ports {cm0[3]}];

set_property -dict { PACKAGE_PIN W18  IOSTANDARD LVCMOS33 } [get_ports {cm1[0]}];
set_property -dict { PACKAGE_PIN U15  IOSTANDARD LVCMOS33 } [get_ports {cm1[1]}];
set_property -dict { PACKAGE_PIN U14  IOSTANDARD LVCMOS33 } [get_ports {cm1[2]}];
set_property -dict { PACKAGE_PIN V14  IOSTANDARD LVCMOS33 } [get_ports {cm1[3]}];