`timescale 1ns/1ps
module tb_project_top_78cm;

    reg clk = 0;
    reg reset = 0;
    wire trig;
    reg echo = 0;
    wire [6:0] seg;
    wire [3:0] an;
    wire [3:0] cm0, cm1;
    wire uart_tx_pin;

    // Instantiate top module
    project_top uut (
        .clk(clk),
        .reset(reset),
        .trig(trig),
        .echo(echo),
        .seg(seg),
        .an(an),
        .cm0(cm0),
        .cm1(cm1),
        .uart_tx_pin(uart_tx_pin)
    );

    // 50 MHz clock (20 ns period)
    always #10 clk = ~clk;

    initial begin
        $dumpfile("tb_project_top_78cm.vcd");
        $dumpvars(0, tb_project_top_78cm);

        reset = 1;
        #200;
        reset = 0;

        // Wait for trigger pulse
        wait (trig == 1);
        wait (trig == 0);

        // Simulate echo pulse corresponding to 78 cm
        #1000;          // Small delay after trigger
        echo = 1;
        #(4524000);     // Echo high for ~4.524 ms (78 cm)
        echo = 0;

        // Wait to observe result
        #10000000;      // 10 ms

        $finish;
    end

endmodule
