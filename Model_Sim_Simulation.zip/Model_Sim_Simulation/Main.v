module embedded_system_control (
    input wire clk,                   // 50 MHz Clock
    input wire reset,                 // Reset
    input wire echo,                  // Echo from sensor
    output reg tx,                    // UART TX
    output reg lcd_rs,                 // LCD RS
    output reg lcd_rw,                 // LCD R/W
    output reg lcd_enable,             // LCD Enable
    output reg [7:0] lcd_data          // LCD Data
);

    // Parameters
    parameter BAUD_RATE = 9600;
    parameter CLOCK_FREQ = 50000000;
    parameter BIT_PERIOD = CLOCK_FREQ / BAUD_RATE;

    // Internal registers
    reg [19:0] counter = 0;
    reg [31:0] pulse_width = 0;
    reg echo_prev = 0;
    reg trigger = 0;
    reg [31:0] distance = 0;

    reg [63:0] driver_data = 64'h4A6F686E20534D49;  // "John SMI"
    reg [63:0] vehicle_data = 64'h546F796F74612043; // "Toyota C"

    reg [1:0] lcd_state = 0;
    reg [7:0] lcd_buffer = 0;
    reg [7:0] lcd_enable_counter = 0;

    // UART signals
    reg tx_enable = 0;
    reg tx_busy = 0;
    reg [9:0] tx_data = 10'b1111111111;
    integer baud_counter = 0;
    reg [3:0] bit_counter = 0;

    // ---------------------------
    // Proximity Sensor Logic
    // ---------------------------
    always @(posedge clk) begin
        // 10us trigger pulse every ~12 ms
        if (counter < 600000)
            counter <= counter + 1;
        else
            counter <= 0;

        trigger <= (counter < 1000); // 1000 cycles ? 20us

        // Rising edge: reset pulse width
        if (echo && !echo_prev)
            pulse_width <= 0;
        // High: increment
        else if (echo)
            pulse_width <= pulse_width + 1;
        // Falling edge: compute distance
        else if (!echo && echo_prev)
            // Convert cycles to us: divide by 50 for 50 MHz
            distance <= ((pulse_width / 50) * 58) / 1000;

        echo_prev <= echo;
    end

    // ---------------------------
    // LCD State Machine
    // ---------------------------
    always @(posedge clk) begin
        lcd_enable_counter <= lcd_enable_counter + 1;
        if (lcd_enable_counter == 0)
            lcd_enable <= 1; // short pulse
        else
            lcd_enable <= 0;

        case (lcd_state)
            2'd0: begin
                lcd_buffer <= driver_data[63:56];
                driver_data <= {driver_data[55:0], 8'b0};
                lcd_state <= 1;
            end
            2'd1: begin
                lcd_buffer <= vehicle_data[63:56];
                vehicle_data <= {vehicle_data[55:0], 8'b0};
                lcd_state <= 2;
            end
            2'd2: begin
                lcd_buffer <= distance[7:0]; // show LSB distance
                lcd_state <= 0;
            end
        endcase
    end

    // LCD control lines
    always @(*) begin
        lcd_rs = 1;
        lcd_rw = 0;
        lcd_data = lcd_buffer;
    end

    // ---------------------------
    // UART Transmission
    // ---------------------------
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            tx <= 1;
            tx_busy <= 0;
            bit_counter <= 0;
            baud_counter <= 0;
            tx_enable <= 0;
        end else begin
            // Enable TX every LCD full cycle as demo
            tx_enable <= (lcd_state == 2);

            if (tx_enable && !tx_busy) begin
                tx_data <= {1'b1, distance[7:0], 1'b0}; // Stop + 8 data + Start
                tx_busy <= 1;
                bit_counter <= 0;
                baud_counter <= 0;
            end else if (tx_busy) begin
                if (baud_counter < BIT_PERIOD)
                    baud_counter <= baud_counter + 1;
                else begin
                    tx <= tx_data[0];
                    tx_data <= {1'b0, tx_data[9:1]};
                    baud_counter <= 0;

                    if (bit_counter == 9)
                        tx_busy <= 0;
                    else
                        bit_counter <= bit_counter + 1;
                end
            end else
                tx <= 1;
        end
    end

endmodule