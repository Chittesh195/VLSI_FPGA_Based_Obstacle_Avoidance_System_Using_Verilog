`timescale 1ns/1ps

module tb_embedded_system_control;

    // Inputs
    reg clk = 0;
    reg reset = 0;
    reg echo = 0;

    // Outputs
    wire tx;
    wire lcd_rs;
    wire lcd_rw;
    wire lcd_enable;
    wire [7:0] lcd_data;

    // Clock period (50 MHz => 20 ns)
    localparam CLK_PERIOD = 20;

    // Instantiate the Unit Under Test (UUT)
    embedded_system_control uut (
        .clk(clk),
        .reset(reset),
        .echo(echo),
        .tx(tx),
        .lcd_rs(lcd_rs),
        .lcd_rw(lcd_rw),
        .lcd_enable(lcd_enable),
        .lcd_data(lcd_data)
    );

    // Clock generation (50 MHz)
    always #(CLK_PERIOD/2) clk = ~clk;

    // Stimulus
    initial begin
        $display("Simulation started at time %0t ns", $time);

        // Step 1: Reset DUT
        reset = 1;
        #(2 * CLK_PERIOD);
        reset = 0;
        #(2 * CLK_PERIOD);

        // Step 2: Simulate Echo for ~30 cm distance (~1.74 ms)
        echo = 1;
        #1_740_000;    // 1.74 ms high pulse
        echo = 0;
        #2_000_000;    // Wait 2 ms for processing

        // Step 3: Display distance
        $display("Time: %0t ns | Measured Distance = %0d cm", $time, uut.distance);

        // Step 4: Observe UART TX for ~1 ms
        #1_000_000;

        // Step 5: Display LCD data on console
        $display("Time: %0t ns | LCD Data Byte = %h", $time, lcd_data);

        // Step 6: End simulation
        $finish;
    end

endmodule